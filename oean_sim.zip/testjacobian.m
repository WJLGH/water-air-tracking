syms x y

f = [
    x^2 + 2*y; x+y;
];
    

jacobian(f,[x y ])